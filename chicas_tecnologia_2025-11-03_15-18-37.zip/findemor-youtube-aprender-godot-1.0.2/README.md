## Ejemplo proyecto Aprender Godot

Ejemplo de juego sencillo utilizado durante el video para Aprender Godot 
en el canal [https://www.youtube.com/@findemor](https://www.youtube.com/@findemor)


### Versión

Creado con la versión de Godot Engine v4.3.dev3.official

### Atribuciones

El proyecto contiene Assets originales y derivados [la web Kenney](https://www.kenney.nl/assets/scribble-platformer)


### Licencia

Licencia MIT

(Usalo como te de la gana)
